# Pakiet audytowy analizy #32

Pakiet jest samowystarczalnym zapisem wyniku zapisanej analizy działki. Powstał wyłącznie z zapisanego snapshotu — bez ponownego odpytywania źródeł. Umożliwia niezależne sprawdzenie wyniku, geometrii i pochodzenia danych.

## Identyfikacja

- Analiza: #32; działka: 246101_1.0056.155/3.
- Data analizy (UTC): 2026-10-13T20:27:53.337842Z — chwila wykonania analizy. Pakiet nie zawiera czasu eksportu, dzięki czemu ten sam snapshot daje identyczny pakiet.
- Status analizy: partial.
- Kompletność analizy (completeness/1.1): 5 z 10 sekcji sprawdzono; brak: MPZP, zagrożenie powodziowe, droga i dostęp, zabudowa sąsiednia, relacja MPZP–POG. Poza zakresem: uzbrojenie terenu. Do weryfikacji ręcznej: strefy POG, OUZ, OZS, OSDIS. Status nagłówkowy `complete` oznacza, że wszystkie sekcje w zakresie analizy są sprawdzone — nie wiąże się z obowiązywaniem planów ani z brakiem ograniczeń (`analysis.json`: `completeness`).
- Format: audit-package/1; eksporter: audit-exporter/1.5.0.
- Polityka jakości: quality-policy/1+b6b04f57d008; suma kontrolna macierzy jakości (SHA-256): fb4c5738e3f34aa1d000c1facbe3101bbfad4c814afbc2927e60c3d80dd92868.

## Układy współrzędnych

- **Obliczenia** (pola, udziały, odległości): EPSG:2180 (PUWG 1992, metry). Geometria działki w EPSG:2180 jest w `analysis.json`, w polu `computation.parcel_geometry_epsg2180`.
- **GeoJSON** (`parcel.geojson`, `layers/*.geojson`): EPSG:4326 (WGS 84, kolejność: długość, szerokość; RFC 7946) — do prezentacji i wymiany. Nie licz pól ani odległości na tych współrzędnych.

## Zawartość

| Plik | Opis |
| --- | --- |
| `analysis.json` | wynik analizy (sekcje, parametry, statusy, macierz jakości, ostrzeżenia); geometrie są w plikach GeoJSON |
| `sources.json` | rejestr źródeł: identyfikator z katalogu, adres, czas pobrania, wydanie, SHA-256 artefaktu, licencja i zgoda na redystrybucję |
| `parcel.geojson` | obrys działki (EPSG:4326) |
| `layers/buildable_area.geojson` | Obszar po technicznym odsunięciu od granic (przybliżenie) — 1 obiekt(ów), EPSG:4326 |
| `layers/mpzp_acts.geojson` | Akty MPZP przecinające działkę (Rejestr Urbanistyczny) — 2 obiekt(ów), EPSG:4326 |
| `layers/pog_overlays.geojson` | OUZ, OZS i OSDIS przecinające działkę — 1 obiekt(ów), EPSG:4326 |
| `layers/pog_zones.geojson` | Strefy POG przecinające działkę — 1 obiekt(ów), EPSG:4326 |
| `layers/terrain_profile.geojson` | Linia profilu wysokościowego (NMT) — 1 obiekt(ów), EPSG:4326 |
| `manifest.json` | lista plików z rozmiarem i SHA-256 (bez samego manifestu) oraz pominięte artefakty |
| `README.md` | ten opis |

Brak pliku warstwy nie dowodzi braku ograniczeń: oznacza brak obiektów w wyniku albo pominięcie warstwy (patrz „Pominięte artefakty”). Brak danych to nie brak ograniczenia, a `null` to nie zero.

## Znaczenie statusów sekcji

Status opisuje wynik sprawdzenia według kontraktu źródła, a nie świeżość danych.

| Status | Znaczenie |
| --- | --- |
| `available` — sprawdzono | źródło zwróciło wynik zgodny z kontraktem; pusty wynik oznacza sprawdzony brak obiektów, a nie brak ograniczeń poza zakresem źródła |
| `partial` — częściowo | wynik jest niepełny albo obniżonej pewności (np. strefa bez wektora, podgląd zamiast geometrii, sprzeczne parametry) |
| `no_coverage` — brak pokrycia źródła | źródło potwierdziło brak danych dla tego obszaru (np. poza zasięgiem NMT albo powiat nie publikuje GESUT) — to nie jest błąd źródła i nie dowodzi braku ograniczeń |
| `unavailable` — źródło niedostępne | próba pobrania nie powiodła się (limit czasu, błąd HTTP, odpowiedź niezgodna z kontraktem) — wynik nie jest znany |
| `error` — błąd sprawdzenia | nieoczekiwany błąd przetwarzania sekcji — wynik nie jest znany |
| `unknown` — nieustalone | brak zapisanego wyniku albo niemożliwe rozstrzygnięcie; brak danych nie oznacza braku ograniczenia ani braku planu |
| `out_of_scope` — poza zakresem | sekcja nie jest analizowana, bo brakuje potwierdzonego kontraktu źródła |
| `awaiting_input` — oczekuje na dane użytkownika | analiza wstrzymana do czasu podania danych przez użytkownika |

## Stan ustalenia MPZP i akty

`analysis.json` zawiera `result.mpzp_status` (jeden z sześciu rozłącznych stanów, kod powodu, stan kanałów KIMPZP i Rejestru Urbanistycznego, akty odrzucone z diagnostyką) oraz `result.mpzp_acts[]` (akty z numerem uchwały, statusem, dokumentem, udziałem działki i pierwszeństwem informacyjnym). Akt to granica i dokument planu, nie strefa. Granice aktów są w `layers/mpzp_acts.geojson` (Rejestr Urbanistyczny, `redistribution: allowed`); akt znany tylko z KIMPZP nie ma granicy, więc jego udział to `null`, nie zero.

| Stan | Znaczenie |
| --- | --- |
| `available` — Ustalono akt MPZP | Dla działki ustalono co najmniej jeden akt MPZP przecinający jej obszar (źródło, udział powierzchni i dokument są w tabeli aktów). Wynik jest informacyjny i nie zastępuje wypisu z planu miejscowego. |
| `ambiguous` — Wiele planów — brak rozstrzygnięcia | Działkę obejmuje więcej niż jeden akt MPZP, a dane nie rozstrzygają, który z nich decyduje o przeznaczeniu. System nie wybiera aktu: wszystkie uchwały są wymienione i wymagają ręcznej weryfikacji w treści dokumentów. |
| `no_match` — Nie znaleziono planu | Usługi odpowiedziały, ale nie wskazały aktu MPZP przecinającego działkę. To obserwacja z dnia analizy, a nie dowód braku planu ani braku ograniczeń — sprawdź MPZP w gminie. |
| `no_coverage` — Brak pokrycia danymi | Dla obszaru działki nie ma usługi planistycznej (KIMPZP: „brak serwisu dla wskazanego obszaru”), a Rejestr Urbanistyczny nie wskazał aktu. To brak danych, a nie brak planu — sprawdź MPZP w gminie. |
| `unavailable` — Nie sprawdzono — błąd źródła | Usługa MPZP nie odpowiedziała poprawnie (błąd albo przekroczony czas), więc nie ustalono, czy dla działki obowiązuje plan. Błąd źródła nie oznacza braku ograniczeń — ponów analizę później albo sprawdź MPZP w gminie. |
| `unknown` — Nie ustalono | Odpowiedź źródeł nie pozwala ustalić, czy dla działki obowiązuje plan (nierozpoznany format albo rozpoznanie się nie wykonało). Wymagana ręczna weryfikacja MPZP w gminie. |

Stan w tej analizie: `available` — Ustalono akt MPZP (kod powodu: `MPZP_ACT_FOUND`; reguła pierwszeństwa: `mpzp-act-precedence/1.0`).

Świeżość jest oceniana osobno, według jawnej reguły wieku przypisanej do źródła i punktu odniesienia (chwila analizy). Źródło bez reguły ma świeżość `unknown` — system nie zgaduje terminu ważności.

| Świeżość | Znaczenie |
| --- | --- |
| `fresh` — aktualne wg reguły | wiek danych w punkcie odniesienia mieści się w regule wieku przypisanej do źródła |
| `stale` — starsze niż reguła | wiek danych w punkcie odniesienia przekracza regułę wieku źródła — dane mogą nie odzwierciedlać bieżącego stanu źródła |
| `unknown` — świeżość nieustalona | brak reguły wieku dla źródła, brak czasu pobrania albo czas nieprawidłowy — system nie zgaduje terminu ważności |

Flaga `manual_review_required` oznacza, że wynik sekcji wymaga ręcznej weryfikacji w materiale źródłowym; nie zmienia statusu sekcji.

## Parametry MPZP: wartości warunkowe i sprzeczności

Parametry strefy są w `analysis.json` pod `result.mpzp_zones[].parameters[]`; każda wartość to osobny wpis z dowodem (`evidence_text`, `page_number`, `raw_value`, SHA-256 dokumentu). Uchwała podaje często kilka wartości tego samego parametru, każdą dla innego przypadku, dlatego wpis niesie też:

| Pole | Znaczenie |
| --- | --- |
| `conditions[]` | warunki wartości: `kind` (`building_type`, `roof_type`, `subzone`, `location`, `other`), `label` (nazwa znormalizowana) i `quote` (dosłowny cytat z uchwały; cytat z nagłówka nadrzędnej pozycji listy nie musi leżeć w `evidence_text`). Pusta lista = wartość bezwarunkowa |
| `value_kind` | `unconditional` — bez warunku; `conditional` — wartość alternatywna z warunkami (np. inna wysokość dla dachu płaskiego), **nie sprzeczność**; `conflict` — ta sama przesłanka ma kilka różnych wartości, wymaga ręcznej weryfikacji (wpisy mają wspólne `conflict_group_id`) |

Płaskie pole strefy (np. `max_building_height_m`) ma wartość tylko wtedy, gdy uchwała podaje dokładnie jedną wartość bezwarunkową; w przeciwnym razie jest `null` (brak jednej wartości dla całej strefy, nie zero), a wartości z warunkami należy czytać z `parameters[]`. Pakiet z eksportera starszego niż 1.1.0 nie ma tych pól: wartości z takich snapshotów traktuj jako bezwarunkowe.

## Parametry MPZP: odczyt automatyczny (model językowy)

Wartość oznaczona `review_status: ai_candidate` (`extraction_method: llm_verified`) pochodzi z odczytu automatycznego modelem językowym: **odczyt automatyczny (model językowy), zweryfikowany z cytatem — wymaga potwierdzenia**. Model zaproponował wartość, a program potwierdził wyłącznie, że cytat i liczba występują w tekście uchwały na wskazanej stronie — wartość jest kandydatem do ręcznej weryfikacji, nigdy „verified”, i nie wypełnia płaskich pól strefy. Odczyt automatyczny nie jest interpretacją prawną: model językowy zaproponował wartość, a program potwierdził jedynie, że cytat i liczba występują w tekście uchwały na wskazanej stronie. Treść, zakres i warunki obowiązywania ustalenia należy potwierdzić w uchwale.

Provenance wszystkich takich wartości jest zebrany w `analysis.json` pod `model_provenance`:

| Pole | Znaczenie |
| --- | --- |
| `model_id`, `prompt_version` | model i wersja instrukcji, które zaproponowały wartość |
| `response_sha256` | skrót SHA-256 odpowiedzi modelu zapisanej w systemie (treść odpowiedzi **nie** jest dołączona: `model_responses_included: false`) |
| `quote`, `quote_sha256`, `quote_included` | zweryfikowany cytat z uchwały i jego skrót (SHA-256 kanonicznego zapisu JSON cytatu — ten sam co w `redactions`). Cytat jest dosłownym fragmentem źródła, więc trafia do pakietu tylko wtedy, gdy katalog źródeł pozwala na redystrybucję surowych danych (`redistribution: allowed`); w przeciwnym razie `quote` i pola `evidence_text`, `raw_value`, cytaty warunków w `result` są `null`, a pozostaje skrót, powód (`quote_omitted_reason`) i wpis w `redactions` |
| `redistribution` | zgoda na redystrybucję źródła strefy z katalogu |
| `page_number`, `document_sha256` | strona i skrót dokumentu uchwały |

Gdy ścieżka modelu była niedostępna albo bramki odrzuciły kandydatów, wynik pochodzi z rdzenia deterministycznego, a `model_provenance.warnings` zawiera odpowiednie ostrzeżenia (`MPZP_LLM_UNAVAILABLE`, `MPZP_LLM_CANDIDATES_REJECTED`). Brak wartości (`null`) nie jest zerem, a brak danych nie oznacza braku ograniczenia. Pakiet z eksportera starszego niż 1.2.0 nie ma bloku `model_provenance`.

## Macierz jakości tej analizy

| Sekcja | Status | Źródło | Pobrano (UTC) | Świeżość | Weryfikacja | Powody |
| --- | --- | --- | --- | --- | --- | --- |
| parcel | available | uldk | 2026-10-13T20:27:42.097667Z | unknown | nie | — |
| mpzp | partial | mpzp_ru | 2026-10-13T20:27:43.158557Z | unknown | tak | KIMPZP wskazało akt planu, ale nie ustalono strefy ani parametrów; ustalono akt MPZP przecinający działkę; kod źródła: KIMPZP_SERVICE_ERROR; usługa MPZP gminy zwróciła błąd — nie ustalono, czy obowiązuje plan; źródło oznaczyło wynik jako wymagający weryfikacji |
| pog | available | pog_app | 2026-10-13T19:19:49.999838Z | unknown | tak | wynik POG wymaga ręcznej weryfikacji |
| pog_overlays | available | pog_app | 2026-10-13T19:19:49.999838Z | unknown | tak | wynik POG wymaga ręcznej weryfikacji |
| flood | unavailable | isok | 2026-10-13T20:27:42.205089Z | fresh | tak | usługa zwróciła błąd HTTP |
| nature | available | gdos | 2026-10-13T20:27:42.205911Z | fresh | nie | — |
| terrain | available | nmt | 2026-10-13T20:27:42.800956Z | fresh | nie | — |
| utilities | partial | kiut_wms | 2026-10-13T20:27:42.203684Z | unknown | nie | podgląd nie jest geometrią sieci — brak odległości i liczby sieci |
| transport | no_coverage | bdot10k | brak danych | unknown | nie | nie zaimportowano żadnego wydania BDOT10k |
| buildings | no_coverage | bdot10k | brak danych | unknown | nie | nie zaimportowano żadnego wydania BDOT10k |
| mpzp_pog_relation | unknown | brak | brak danych | unknown | tak | POG obowiązuje, ale nie ustalono strefy MPZP (brak danych ≠ brak ograniczeń); relacja MPZP–POG wymaga weryfikacji; sekcja wyliczona z innych sekcji — bez własnego źródła |

## Pominięte artefakty (redystrybucja)

Wszystkie artefakty dozwolone przez katalog źródeł zostały dołączone.

## Weryfikacja integralności

1. Rozpakuj archiwum. `manifest.json` zawiera nazwę, rozmiar i SHA-256 każdego pliku (poza samym manifestem).
2. Sprawdź każdy plik, np. `sha256sum analysis.json` i porównaj z manifestem. Zmiana jednego bajtu zmienia sumę.
3. Skrypt `backend/scripts/verify_audit_package.py <plik.zip|katalog>` sprawdza wszystko offline (tylko biblioteka standardowa Pythona).
4. Hash całej paczki ZIP nie jest w archiwum; podano go w nagłówku odpowiedzi `X-Audit-Package-SHA256`.

## Zastrzeżenia

Pakiet nie jest opinią prawną. Podgląd WMS służy wyłącznie prezentacji i nie jest źródłem obliczeń. Wynik zależy od stanu źródeł w chwili analizy.
